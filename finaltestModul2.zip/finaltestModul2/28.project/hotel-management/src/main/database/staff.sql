CREATE TABLE `staffs` (
  `id` varchar(45) NOT NULL,
  `staff_id` varchar(45) NOT NULL,
  `staff_group` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `day_of_birth` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `phone_number` varchar(45) NOT NULL,
  `id_number` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `address` varchar(100) NOT NULL,
  `deleted` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci