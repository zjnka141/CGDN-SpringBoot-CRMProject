package com.codegym.hotelmanagement.repository;


import com.codegym.hotelmanagement.entity.Staff;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;

import java.awt.print.Pageable;

public interface StaffRepository extends JpaRepository<Staff, String> {
Iterable<Staff> findAllByDeletedIsFalse();
}
