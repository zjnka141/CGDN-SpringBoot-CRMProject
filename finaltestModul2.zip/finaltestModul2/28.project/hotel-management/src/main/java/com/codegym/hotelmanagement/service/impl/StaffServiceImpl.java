package com.codegym.hotelmanagement.service.impl;

import com.codegym.hotelmanagement.dto.StaffDTO;
import com.codegym.hotelmanagement.entity.Staff;
import com.codegym.hotelmanagement.repository.StaffRepository;
import com.codegym.hotelmanagement.service.StaffService;
import constants.AppConsts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class StaffServiceImpl implements StaffService {
    @Autowired
    StaffRepository staffRepository;

    @Override
    public Iterable<Staff> findAllByDeletedIsFalse() {
        return staffRepository.findAllByDeletedIsFalse();
    }

    @Override
    public void create(StaffDTO staffDTO) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(AppConsts.STRING_TO_DATE_FORMAT);
        LocalDate dayOfBirth = LocalDate.parse(staffDTO.getDayOfBirth(), formatter);
        Staff staff = new Staff();
        staff.setStaffGroup(staffDTO.getStaffGroup());
        staff.setName(staffDTO.getName());
        staff.setStaffId(staffDTO.getStaffId());
        staff.setDayOfBirth(dayOfBirth);
        staff.setGender(staffDTO.getGender());
        staff.setPhoneNumber(staffDTO.getPhoneNumber());
        staff.setIdNumber(staffDTO.getIdNumber());
        staff.setEmail(staffDTO.getEmail());
        staff.setAddress(staffDTO.getAddress());
        staff.setDeleted(Boolean.FALSE);
        staffRepository.save(staff);
    }

    @Override
    public void update(StaffDTO staffDTO) {
        Staff staff = staffRepository.findById(staffDTO.getId()).orElse(null);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(AppConsts.STRING_TO_DATE_FORMAT);
        LocalDate dayOfBirth = LocalDate.parse(staffDTO.getDayOfBirth(), formatter);
        staff.setStaffGroup(staffDTO.getStaffGroup());
        staff.setName(staffDTO.getName());
        staff.setStaffId(staffDTO.getStaffId());
        staff.setDayOfBirth(dayOfBirth);
        staff.setPhoneNumber(staffDTO.getPhoneNumber());
        staff.setGender(staffDTO.getGender());
        staff.setPhoneNumber(staffDTO.getPhoneNumber());
        staff.setIdNumber(staffDTO.getIdNumber());
        staff.setEmail(staffDTO.getEmail());
        staff.setAddress(staffDTO.getAddress());
        staffRepository.save(staff);
    }

    @Override
    public StaffDTO findById(String id){
    Staff staff = staffRepository.findById(id).orElse(null);

    if(staff !=null) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(AppConsts.STRING_TO_DATE_FORMAT);
        String dayOfBirth = staff.getDayOfBirth().format(formatter);
        StaffDTO staffDTO = new StaffDTO();
        staffDTO.setId(staff.getId());
        staffDTO.setStaffGroup(staff.getStaffGroup());
        staffDTO.setStaffId(staff.getStaffId());
        staffDTO.setName(staff.getName());
        staffDTO.setDayOfBirth(dayOfBirth);
        staffDTO.setPhoneNumber(staff.getPhoneNumber());
        staffDTO.setGender(staff.getGender());
        staffDTO.setIdNumber(staff.getIdNumber());
        staffDTO.setEmail(staff.getEmail());
        staffDTO.setAddress(staff.getAddress());
        staffDTO.setDeleted(staff.isDeleted());
        return staffDTO;
    }
    return null;
    }
    @Override
    public void delete(String id) {
        Staff staff = staffRepository.findById(id).orElse(null);
        staff.setDeleted(true);
        staffRepository.save(staff);
    }
}




