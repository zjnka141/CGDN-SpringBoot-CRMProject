package com.codegym.hotelmanagement.controller;

import com.codegym.hotelmanagement.dto.StaffDTO;
import com.codegym.hotelmanagement.entity.Staff;
import com.codegym.hotelmanagement.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.Optional;

@Controller
@RequestMapping("/staffs")
public class StaffController {
    @Autowired
    private StaffService staffService;

    @GetMapping("/create")
    public ModelAndView showCreateForm() {
        ModelAndView modelAndView = new ModelAndView("create");
        modelAndView.addObject("staff", new StaffDTO());
        return modelAndView;
    }
    @PostMapping("/create")
    public String saveLead(@Valid @ModelAttribute("staff") StaffDTO staffDTO, BindingResult bindingResult, RedirectAttributes redirect) {
        if (bindingResult.hasErrors()) {
            return "/create";
        } else {
            staffService.create(staffDTO);
            redirect.addFlashAttribute("message", "New staff created successfully!");
            return "redirect:/staffs/list";
        }
    }

    @GetMapping("/list")
    public ModelAndView listLeads() {
        Iterable<Staff> staffs;
        ModelAndView modelAndView = new ModelAndView("list");
        staffs = staffService.findAllByDeletedIsFalse();
        modelAndView.addObject("staffs", staffs);
        return modelAndView;
    }

    @GetMapping("/edit/{id}")
    public ModelAndView showEditForm(@PathVariable String id) {
        StaffDTO staffDTO = staffService.findById(id);
        if (staffDTO != null) {
            ModelAndView modelAndView = new ModelAndView("edit");
            modelAndView.addObject("staff", staffDTO);
            return modelAndView;
        } else {
            return new ModelAndView("error 404");
        }
    }
    @PostMapping("/edit")
    public String updateLead(@Valid @ModelAttribute("staff") StaffDTO staffDTO, BindingResult bindingResult, RedirectAttributes redirect) {
        if (bindingResult.hasErrors()) {
            return "edit";
        } else {
            staffService.update(staffDTO);
            redirect.addFlashAttribute("message", "Staff updated successfully!");
            return "redirect:/staffs/list";
        }
    }

    @GetMapping("/delete/{id}")
    public ModelAndView showDeleteForm(@PathVariable String id) {
        StaffDTO staffDTO = staffService.findById(id);
        if (staffDTO != null) {
            ModelAndView modelAndView = new ModelAndView("delete");
            modelAndView.addObject("staff", staffDTO);
            return modelAndView;
        } else {
            return new ModelAndView("error 404");
        }
    }

    @PostMapping("/delete")
    public String deleteLead(@ModelAttribute("staff") StaffDTO staffDTO, RedirectAttributes redirect) {
        staffService.delete(staffDTO.getId());
        redirect.addFlashAttribute("message", "Staff deleted successfully!");
        return "redirect:/staffs/list";
    }

}
