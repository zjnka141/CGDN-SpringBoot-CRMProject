package com.codegym.hotelmanagement.service;

import com.codegym.hotelmanagement.dto.StaffDTO;
import com.codegym.hotelmanagement.entity.Staff;
import org.springframework.data.domain.Page;

import java.awt.print.Pageable;

public interface StaffService {
    Iterable<Staff> findAllByDeletedIsFalse();
    void create(StaffDTO staffDTO);

    void update(StaffDTO staffDTO);

    StaffDTO findById(String id);

    void delete(String idStaff);
}
